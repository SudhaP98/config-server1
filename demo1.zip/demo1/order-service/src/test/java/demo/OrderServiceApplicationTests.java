package demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import demo.common.Payment;
import demo.common.TransactionRequest;
import demo.entity.Customer;
import demo.entity.Order;
import demo.repository.OrderRepository;
import demo.service.OrderService;

@RunWith(SpringRunner.class)
@SpringBootTest
class OrderServiceApplicationTests {

	@Autowired
	private OrderService service;
	
	@MockBean
	private OrderRepository repository;
	
	private MockMvc mockMvc;
	
	@Mock
	 private Order order11;
	
	  @Test
	  public void getOrderDetailsTest() { 
		  when(repository.findAll())
	  .thenReturn(Stream.of(new Order(8, "sD", 20, 480450.0,new Customer(7, "xyz",
	  12333, "abc@gmail.com", "Mumbai")),new Order(5, "Laptop", 20, 4820.0,new
	  Customer(7, "wer", 12333, "def@gmail.com", "Mumbai")))
	  .collect(Collectors.toList()));
	  
	  assertEquals(2,service.getAllOrder().size()); }
	  
	  
	  @Test
	  public void getOrderDetailsByIdTest() { 
		  int id=2;
		 
		  when(repository.findById(id))
	     .thenReturn(Optional.empty());
	  
	  assertEquals(null,service.getOrderById(id));
	  }
	
	  @Test public void bookOrderTest() {
	   TransactionRequest request=new TransactionRequest(new Order(11, "Laptop1", 20, 480450.0,new Customer(7, "monu", 12333, "radha@gmail.com", "Mumbai")),new Payment(0, null, null, 26, 480450.0));
	  Order order = request.getOrder();
	  Map<String, Boolean> response = new HashMap<>(); 
	  response.put("Posted", Boolean.TRUE); 
		  
	  when(repository.save(order)) .thenReturn(order);
	
	 assertEquals(response,service.saveOrder(request));
	 }
	  
	  @Test
	  public void updateOrderTest() {
		  TransactionRequest request=new TransactionRequest(new Order(11, "Laptop1", 20, 480450.0,new Customer(7, "monu", 12333, "radha@gmail.com", "Mumbai")),new Payment(0, null, null, 11, 480450.0));
		  Order order = request.getOrder();
		  Map<String, Boolean> response = new HashMap<>(); 	 
		  response.put("Posted", Boolean.TRUE); 
		  int id=11;
			  
	     when(repository.save(order)) .thenReturn(order);
		
		 assertEquals(response,service.updateOrder(id,request));
		 } 
	 		
	  
	  @Test
	  public void deleteOrderTest() throws Exception {
		  
		    Optional<Order> order= repository.findById(order11.getId());
		    
	        when(service.deleteOrderById(order11.getId())).thenReturn(order);
	         
	        assertEquals(order,service.deleteOrderById(order11.getId()));
	  }
	  @Test
	  public void deleteAllOrderTest() throws Exception {
		  
		 // when(service.deleteOrder()).thenReturn(order);
		  
		  service.deleteOrder();
		  verify(repository,times(1)).deleteAll();
	  }
	  
	  

	}
