package demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CUSTOMER_TB")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Customer 
{
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	private String name;
    private long mbl;
    private String emailId;
    private String address;
       
    public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
   
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMbl() {
		return mbl;
	}
	public void setMbl(long mbl) {
		this.mbl = mbl;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", mbl=" + mbl + ", emailId=" + emailId
				+ ", address=" + address + "]";
	}
	public Customer(int customerId, String name, long mbl, String emailId, String address) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.mbl = mbl;
		this.emailId = emailId;
		this.address = address;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
    	
}
