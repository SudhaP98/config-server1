package demo.common;

import demo.entity.Customer;
import demo.entity.Order;

public class TrannsactionCusRequest {
	
	private Order order;
	private Customer customer;
    private Payment payment;
    
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Payment getPayment() {
		return payment; 
		} 
	public void setPayment(Payment payment) { 
		this.payment = payment; 
		}
	 
}
