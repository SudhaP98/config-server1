package demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import demo.common.*;
import demo.entity.Order;
import demo.repository.OrderRepository;

@Service
public class OrderServiceImp implements OrderService {
	@Autowired
	private OrderRepository repository;

	@Autowired
	private RestTemplate template;
	
	 @Override
	 public Map<String, Boolean> saveOrder(TransactionRequest request) {
		String response = "";
		Order order = request.getOrder();
		Payment payment = request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		
		Payment paymentResponse = template.postForObject("http://PAYMENT-SERVICE/payment/doPayment", payment,
				Payment.class);

		response = paymentResponse.getPaymentStatus().equals("success") ? "payment processing successful":"there is a failure";
		

		repository.save(order);

		System.out.println("request--------"+request);
		  Map<String, Boolean> response1 = new HashMap<>(); 
		  response1.put("Posted", Boolean.TRUE); 
		  return response1;
	}

	
	  @Override
	  public Map<String, Boolean> updateOrder(int id, TransactionRequest request) {
	  String response = ""; 
	  Order updateOrder = repository.findById(id).orElseThrow();
	  Payment payment =  request.getPayment();
	  
	  payment.setOrderId(updateOrder.getId());
	  payment.setAmount(updateOrder.getPrice());
	  
	  Payment paymentResponse =
	  template.postForObject("http://PAYMENT-SERVICE/payment/doPayment", payment, Payment.class);
	  
	  response = paymentResponse.getPaymentStatus().equals("success") ? "payment processing successful" : "there is a failure";
	  
	  updateOrder.setName(request.getOrder().getName());
	  updateOrder.setPrice(request.getOrder().getPrice());
	  updateOrder.setQty(request.getOrder().getQty());
	  
	  repository.save(updateOrder);
	  
	 
	  Map<String, Boolean> response1 = new HashMap<>(); 
	  response1.put("Updated", Boolean.TRUE); 
	  return response1;
	  }
	  
	  @Override
	  public Order getOrderById(int id) { Optional<Order> order =
	  repository.findById(id);
	  
	  if (order.isPresent()) {
		  return order.get();
		  } else {
			  return null;
	      }
	  }
	  
	  @Override
	  public List<Order> getAllOrder() { 
		  
		  List<Order> order = repository.findAll();
		  System.out.println("List------"+order);
	     return order; 
	  }
	  
	  @Override
	  public  Optional<Order> deleteOrderById(int id) {
	  
		  Order order1=null;
	  Optional<Order> order= repository.findById(id);
	  
	  if(order.isPresent()) 

	  { 
		  order1 = order.get();
		  repository.deleteById(id);
	  }
	  Map<String, Boolean> response = new HashMap<>(); 
	  response.put("deleted", Boolean.TRUE); 
	  return Optional.ofNullable(order1); }
	   
	  
	  @Override
	  public void deleteOrder(){ repository.deleteAll(); }
	  
	  
	 }
