package demo.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import demo.common.TransactionRequest;
import demo.entity.Order;

public interface OrderService
{
	
      public Map<String, Boolean> saveOrder(TransactionRequest request); 
	
	  public Map<String, Boolean> updateOrder(int id, TransactionRequest request);
	  
	  public Order getOrderById(int id);
	  
	  public  Optional<Order> deleteOrderById(int id);
	  
	  public List<Order> getAllOrder();
	  
	  public void deleteOrder();	 
 
}
