package demo.repository;

import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import demo.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order,Integer> 
{
	  public Order getOrderById(int id);
	  public  Optional<Order> deleteOrderById(int id);
	  
}
