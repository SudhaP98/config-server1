package demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import demo.common.TransactionRequest;
import demo.entity.Order;
import demo.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController 
{
	@Autowired
	private OrderService service;
	
	@PostMapping("/bookOrder")
	public Map<String, Boolean> bookOrder(@RequestBody TransactionRequest request)
	{
		String name=request.getOrder().getName();
	    System.out.println("Add User"+ name);
		System.out.println("test");
		return service.saveOrder(request);
	}
	
	@GetMapping("/{id}")
	public Order getOrderDetails(@PathVariable int id)
	{
		System.out.println("get Order");
		return service.getOrderById(id);
	}
	
	
	@GetMapping("/GetAllOrder")
	public List<Order> getOrderDetails()
	{
		System.out.println("get Order");
		return service.getAllOrder();
	}
	
	@PutMapping("/{id}")
    public Map<String, Boolean> updateOrder(@PathVariable int id,@RequestBody TransactionRequest request) {
		System.out.println("update test");
        return service.updateOrder(id,request);
    }
	
	@DeleteMapping("/{id}")
	public  Optional<Order> deleteOrder(@PathVariable int id) {

	      return  service.deleteOrderById(id);
	}
	@DeleteMapping("/deleteAllOrder")
    public  void deleteAllOrder() {

	    service.deleteOrder();
	 	System.out.println("Deleted");
    }	
}
