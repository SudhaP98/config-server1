package demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "PRODUCT_TB")
@Data

public class Product {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int productId;
    private String Name;
    private long Image;
    private String Thumbnail;
    private String description;
    private String sortDecription;
    private int ratings;
    private double price;
    private int isActive;
    
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String name, long image, String thumbnail, String description, String sortDecription,
			int ratings, double price, int isActive) {
		super();
		this.productId = productId;
		Name = name;
		Image = image;
		Thumbnail = thumbnail;
		this.description = description;
		this.sortDecription = sortDecription;
		this.ratings = ratings;
		this.price = price;
		this.isActive = isActive;
	}
		
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getImage() {
		return Image;
	}
	public void setImage(long image) {
		Image = image;
	}
	public String getThumbnail() {
		return Thumbnail;
	}
	public void setThumbnail(String thumbnail) {
		Thumbnail = thumbnail;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSortDecription() {
		return sortDecription;
	}
	public void setSortDecription(String sortDecription) {
		this.sortDecription = sortDecription;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int isActive() {
		return isActive;
	}
	public void setActive(int isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", Name=" + Name + ", Image=" + Image + ", Thumbnail=" + Thumbnail
				+ ", description=" + description + ", sortDecription=" + sortDecription + ", ratings=" + ratings
				+ ", price=" + price + ", isActive=" + isActive + "]";
	}
	
	
   
}
