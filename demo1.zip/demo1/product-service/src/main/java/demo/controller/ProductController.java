package demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.common.TransactionRequest;
import demo.common.TransactionResponse;

import demo.entity.Product;
import demo.service.ProductService;

@RestController
@ComponentScan
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private ProductService service;

	@PostMapping("/bookProduct")
	public TransactionResponse bookProduct(@RequestBody TransactionRequest request)
	{
		
		System.out.println("test");
		return service.saveProduct(request);
	}
	
	@GetMapping("/{productId}")
	public Product getOrderDetails(@PathVariable int productId)
	{
		System.out.println("get Order");
		return service.getProductById(productId);
	}

}
