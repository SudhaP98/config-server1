package demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import demo.common.TransactionRequest;
import demo.common.TransactionResponse;

import demo.entity.Product;
import demo.repository.ProductRepository;

@Service
public class ProductServiceImp implements ProductService {

	@Autowired
	private ProductRepository repository;

	@Autowired
	private RestTemplate template;
	
	
	@Override
	public TransactionResponse saveProduct(TransactionRequest request) {

		Product product = request.getProduct();
		repository.save(product);

		return new TransactionResponse();
		
	}


	@Override
	public Product getProductById(int productId) {
		Optional<Product> product =  repository.findById(productId);
	
		 if (product.isPresent()) {
			 return product.get();
			 } 
		 else { 
			 return null;
	          }
	}

	
}
