package demo.service;

import demo.common.TransactionRequest;
import demo.common.TransactionResponse;

import demo.entity.Product;

public interface ProductService {
	public TransactionResponse saveProduct(TransactionRequest request);
	
	 public Product getProductById(int productId);
}
