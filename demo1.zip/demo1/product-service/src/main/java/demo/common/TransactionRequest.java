package demo.common;

import demo.entity.Product;

public class TransactionRequest 
{
	private Product product;

	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	

	
}
